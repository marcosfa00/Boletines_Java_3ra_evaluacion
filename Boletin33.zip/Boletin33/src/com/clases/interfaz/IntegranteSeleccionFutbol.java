/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.clases.interfaz;

/**
 *
 * @author marcosfa
 */
public interface IntegranteSeleccionFutbol {
    
    public abstract void concentrarse();
    public abstract void viajar();
    public abstract void entrenar();
    public abstract void jugarPartido();
}
